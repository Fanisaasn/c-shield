Demo ini menggunakan animasi HTML/CSS, bukan rekaman video, dengan narasi bahasa Indonesia melalui suara browser.

Buka index.html lalu tekan Putar. Adegan pertama menampilkan orang di meja, membuka laptop, login, menerima email, dan mengeklik tautan. Animasi dijeda untuk pertanyaan Aman/Berisiko. Setelah jawaban dipilih, penjelasan muncul dan tombol Lanjutkan Video aktif. Tombol tersebut memutar sisa adegan sebelum berpindah ke adegan berikutnya.

Ada lima adegan. Hasil dihitung sekali per adegan. Progres hanya untuk melihat waktu agar pertanyaan tidak terlewati. Tombol Ulangi latihan menghapus jawaban dan memulai kembali.

Durasi, waktu jeda (assessmentAt), tindakan, jawaban benar (safe), dan penjelasan diatur dalam scenes pada script.js. Seluruh animasi mengikuti waktu pemutaran sehingga ikut berhenti ketika dijeda.

Untuk memakai rekaman asli, tambahkan MP4 dan integrasikan elemen video beserta event timeupdate, pause, dan play. Folder ini belum berisi aset video.

Narasi: tekan Putar untuk memulai. Pilihan Narator memprioritaskan nama suara wanita Indonesia yang dikenal jika tersedia. Browser tidak menyediakan informasi gender suara, sehingga suara wanita tidak dijamin pada semua perangkat. Pilih suara yang sesuai melalui menu Narator. Tombol speaker mematikan narasi. Jika suara Indonesia tidak terdaftar, browser mencoba suara bawaan dengan bahasa id-ID. Ketersediaan dan kebutuhan internet bergantung pada penyedia suara perangkat. Tidak ada file audio rekaman yang disertakan.
